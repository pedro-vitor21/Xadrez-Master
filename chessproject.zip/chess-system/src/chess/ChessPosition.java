package chess;

import boardgame.Position;

public class ChessPosition {

    private char column;
    private int row;

    // Construtor com coordenadas de coluna e linha
    public ChessPosition(char column, int row) {
        if (column < 'a' || column > 'h' || row < 1 || row > 8) {
            throw new ChessException("Error instantiating ChessPosition. Valid values are from a1 to h8.");
        }
        this.column = column;
        this.row = row;
    }

    // Construtor com coordenadas de matriz
    public ChessPosition(int row, int column) {
        if (column < 0 || column > 7 || row < 0 || row > 7) {
            throw new ChessException("Error instantiating ChessPosition. Valid values are from (0,0) to (7,7).");
        }
        this.column = (char) ('a' + column);
        this.row = 8 - row;
    }

    public char getColumn() {
        return column;
    }

    public int getRow() {
        return row;
    }

    protected Position toPosition() {
        return new Position(8 - row, column - 'a');
    }

    protected static ChessPosition fromPosition(Position position) {
        return new ChessPosition((char) ('a' + position.getColumn()), 8 - position.getRow());
    }

    @Override
    public String toString() {
        return "" + column + row;
    }
}
