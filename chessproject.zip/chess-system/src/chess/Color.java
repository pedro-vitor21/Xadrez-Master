package chess;

public enum Color {
	BLACK,
	WHITE;
}
