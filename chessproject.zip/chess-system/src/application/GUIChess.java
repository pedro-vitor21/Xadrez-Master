package application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import chess.ChessMatch;
import chess.ChessPiece;
import chess.ChessPosition;

public class GUIChess extends JFrame {
    private JPanel boardPanel;
    private JButton[][] squares;
    private ChessMatch chessMatch;
    private LoginPanel loginPanel; // Adiciona um painel para a interface de login
    private ScoreTablePanel scoreTablePanel; // Adiciona um painel para a tabela de score

    public GUIChess() {
        setTitle("Xadrez");
        setSize(800, 600); // Ajusta o tamanho para acomodar a interface de login e a tabela de score
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        chessMatch = new ChessMatch(); // Instancia uma partida de xadrez

        initializeBoard();
        initializeLoginPanel(); // Inicializa o painel de login
        initializeScoreTablePanel(); // Inicializa o painel da tabela de score

        setVisible(true);
    }

    private void initializeBoard() {
        boardPanel = new JPanel();
        boardPanel.setLayout(new GridLayout(8, 8));
        squares = new JButton[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                JButton button = new JButton();
                // Define as dimensões do botão
                button.setPreferredSize(new Dimension(60, 60));

                // Define a cor de fundo do botão de acordo com a posição no tabuleiro
                if ((i + j) % 2 == 0) {
                    button.setBackground(Color.WHITE);
                } else {
                    button.setBackground(Color.GRAY);
                }

                // Adiciona um nome ao botão para identificar sua posição no tabuleiro
                button.setName("(" + i + ", " + j + ")");

                // Adiciona um ActionListener para manipular os cliques nos botões
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Aqui você pode adicionar a lógica para manipular os cliques nos botões do tabuleiro
                        JButton clickedButton = (JButton) e.getSource();
                        // Por exemplo, obter a posição do botão clicado
                        String positionStr = clickedButton.getName();
                        int row = Character.getNumericValue(positionStr.charAt(1));
                        int col = Character.getNumericValue(positionStr.charAt(3));
                        ChessPosition sourcePosition = new ChessPosition(col, row);
                        ChessPosition targetPosition = new ChessPosition(col, row); // Posição de destino igual à de origem para teste

                        // Executar um movimento de teste
                        chessMatch.performChessMove(sourcePosition, targetPosition);

                        // Atualizar a interface gráfica com as novas posições das peças
                        updateBoard();
                    }
                });

                // Adiciona o botão ao array de botões do tabuleiro
                squares[i][j] = button;

                // Adiciona o botão ao painel do tabuleiro
                boardPanel.add(button);
            }
        }
        add(boardPanel, BorderLayout.CENTER); // Posiciona o tabuleiro no centro do JFrame

        // Adiciona as peças ao tabuleiro
        updateBoard();
    }

    private void initializeLoginPanel() {
        loginPanel = new LoginPanel();
        // Adiciona o painel de login ao JFrame
        add(loginPanel, BorderLayout.WEST); // Posiciona o painel de login à esquerda do JFrame
    }

    private void initializeScoreTablePanel() {
        scoreTablePanel = new ScoreTablePanel();
        // Adiciona o painel da tabela de score ao JFrame
        add(scoreTablePanel, BorderLayout.EAST); // Posiciona o painel da tabela de score à direita do JFrame
    }

    private void updateBoard() {
        ChessPiece[][] pieces = chessMatch.getPieces();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (pieces[i][j] != null) {
                    squares[i][j].setText(pieces[i][j].toString()); // Atualiza o texto do botão com a representação da peça
                } else {
                    squares[i][j].setText(""); // Limpa o texto do botão se não houver peça na posição
                }
            }
        }
    }

    // Classe para a interface de login
    class LoginPanel extends JPanel {
        // Aqui você pode adicionar campos de entrada de usuário e senha, botões de login, etc.
        public LoginPanel() {
            setPreferredSize(new Dimension(200, 600)); // Define o tamanho do painel de login
            setBackground(Color.LIGHT_GRAY); // Define a cor de fundo do painel de login
        }
    }

    // Classe para a tabela de score
    class ScoreTablePanel extends JPanel {
        // Aqui você pode adicionar uma tabela de score com os dados dos jogadores
        public ScoreTablePanel() {
            setPreferredSize(new Dimension(200, 600)); // Define o tamanho do painel da tabela de score
            setBackground(Color.LIGHT_GRAY); // Define a cor de fundo do painel da tabela de score
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new GUIChess(); // Inicializa a GUIChess
            }
        });
    }
}
