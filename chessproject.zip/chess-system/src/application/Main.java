package application;

public class Main {
    public static void main(String[] args) {
        GUIChess guiChess = new GUIChess(); // Cria uma instância da classe GUIChess
    }
}
